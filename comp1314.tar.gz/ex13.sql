SELECT
    STUDENTS.studentID,
    STUDENTS.student_firstname,
    STUDENTS.student_surname,
    AVG(STUDENTMODULES.exam_mark) AS average
FROM STUDENTS
JOIN STUDENTMODULES ON STUDENTS.studentID = STUDENTMODULES.studentID
WHERE STUDENTS.year = 1 AND STUDENTMODULES.moduleID LIKE '%COMP%'
GROUP BY STUDENTS.studentID, STUDENTS.student_firstname, STUDENTS.student_surname
ORDER BY average DESC;